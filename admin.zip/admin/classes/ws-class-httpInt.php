<?php
    /**
     * http interface handler
     * @author : wibgates kenneth , joel.s
     * @copyright : 2018 ws partners
     * @license : MIT
     * @github : git:wibgates/ws_cms
     */
    class httpInt extends users
    {
      public function __construct()
      {
        global $hm , $callBack ;
        if (!empty($_GET)) {
           switch ($_GET) {
             case $_GET['req'] == 'fetch_menu':
                 echo json_encode(menu::fetch($_GET));
               break;

             case $_GET['req'] == 'fetch_logo':
                 echo json_encode(images::stream($_GET));
               break;
             case $_GET['req'] == 'fetch_add':
                 echo json_encode(address::fetch($_GET));
               break;

             case $_GET['req'] == 'fetch_cat':
                 echo json_encode(category::fetch($_GET));
               break;

             case $_GET['req'] == 'fetch_posts':
                 echo json_encode(posts::fetch($_GET));
               break;

             default:
               echo json_encode($callBack);
               unset($_GET);
               break;
           }
        }elseif (!empty($_FILES)) {
          $path = "uploads/";
          if (!file_exists($path)) {
              mkdir($path,0777);
          }
          $newName = rand(11111,99999).'.jpeg' ;
          $path = $path.$newName;

          //from form
          if (isset($_FILES['xname'])) {
             move_uploaded_file($_FILES['xname']['tmp_name'], $path);
          }elseif (isset($_FILES['ajax_img'])) {
             //from ajax
             move_uploaded_file($_FILES['ajax_img']['tmp_name'], $path);
          }
          if (isset($_POST['req']) && $_POST['req'] == 'create_post') {
            posts::create($_POST);
          }
          images::upload($newName,$_POST);

          unset($_FILES);
          unset($_POST);
        }elseif (!empty($_POST)) {
          switch ($_POST) {
            case $_POST['req'] == 'del':
                echo json_encode($this->delete($_POST));
            break;

            case $_POST['req'] == 'regAdmin':
               if ($this->signup($_POST)) {
                 return $this->location('login','inc');
               } else {
                 return $this->location('register','inc');
               }
            break;

            case $_POST['req'] == 'login':
               if ($this->signin($_POST)) {
                 $_SESSION['admin'] = $this->signin($_POST) ;
                 return $this->location('home','inc');
               } else {
                 return $this->location('login','inc');
               }
            break;

            case $_POST['req'] == 'logout':
               $this->logout();
            break;

            case $_POST['req'] == 'menu':
               echo json_encode(menu::create($_POST));
            break;

            case $_POST['req'] == 'save_add':
               echo json_encode(address::save( $_POST));
            break;

            case $_POST['req'] == 'save_cap':
               echo json_encode(images::edit($_POST));
            break;

            case $_POST['req'] == 'save_cat':
               echo json_encode(category::create($_POST));
            break;

            case $_POST['req'] == 'update_cat':
               echo json_encode(category::update($_POST));
            break;

            case $_POST['req'] == 'update_post':
               echo json_encode(posts::update($_POST));
            break;

            default:
              //return die('Fatal error...');
              unset($_POST);
            break;
          }
        }elseif (!empty($_PUT)) {
          // code...
        }else {
          return false;
        }
      }
    }

 ?>
