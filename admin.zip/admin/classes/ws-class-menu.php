<?php
    /**
     * menu manager
     * @author : wibgates kenneth , joel.s
     * @copyright : 2018 ws partners
     * @license : MIT
     * @github : git:wibgates/ws_cms
     */
    class menu extends main
    {

      public static function create($data)
      {
        global $hm , $callBack ;
        $main = new main ;
        $callBack['res'] = 0 ;
        $name = ucwords(trim($data['name']));
        $cmd  = $data['cmd'];
        $list = json_encode($data['list']);
        if ($cmd == 'create') {
          $clink = $data['clink'];
          $type = $data['has'];
          $menu = $hm->query("SELECT `id` FROM `ws_app_menu` WHERE `name`='$name' ");
          if ($menu->rowCount() <= 0 ) {
            $callBack['res'] = 1 ;
            $pos = $main->nextId('ws_app_menu');
            $hm->query("INSERT INTO `ws_app_menu`(`name`, `clink`, `type`, `links`, `pos`)
            VALUES ('".$name."','".$clink."','".$type."','".$list."','".$pos."')");
            $callBack['res'] = 1 ;
          } else {
            $hm->query("UPDATE `ws_app_menu` SET `type`='".$type."', `links`='".$list."'
            WHERE `name`='".$name."' ");
            $callBack['res'] = 1 ;
          }
        } else {
          $id  = $data['id'];
          $pos = $data['pos'];
          $hm->query("UPDATE `ws_app_menu` SET `name`='".$name."', `links`='".$list."' , `pos`='".$pos."'
          WHERE `id`='".$id."' ");
          $callBack['res'] = 1 ;
        }


        return $callBack ;
      }

      //fetch data
      public static function fetch($data)
      {
        global $hm , $callBack ;
        $callBack['res'] = 0 ;
        $limit1 = $data['limit1'];
        $limit2 = $data['limit2'];
        $order  = $data['order'];
        $callBack['data'] = [] ;
        $menu = $hm->query("SELECT * FROM `ws_app_menu` ORDER BY `pos` $order LIMIT $limit2 ");
        $rows = $menu->rowCount() ;
        if ($rows <= 0 ) {
          $callBack['res'] = 0 ;
        } else {
          $obj = [] ;
          while ($dataRows = $menu->fetch()) {
            $obj = [
              'name'=>$dataRows['name'],
              'id'=>$dataRows['id'],
              'click'=>$dataRows['clink'],
              'links'=>$dataRows['links'],
              'pos'=>$dataRows['pos'],
              'type'=>$dataRows['type']
            ] ;
            array_push($callBack['data'] , $obj);
          }
          $callBack['res'] = 1 ;
        }
        return $callBack ;
      }
    }

 ?>
