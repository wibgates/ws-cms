<?php
    /**
     * main class:global fuctions
     * @author : wibgates kenneth , joel.s
     * @copyright : 2018 ws partners
     * @license : MIT
     * @github : git:wibgates/ws_cms
     */
    class main
    {
      /**
       * content manager
       * set mimes based on what page content
       * your are throwing to the browser
       * the default mime is html
       */

      public function location($value='',$mode=null,$mime='html')
      {
        if ($mode == null) {
          mimes::mime($mime);
          return header('location:pages/'.$value);
        } else {
          mimes::mime($mime);
          include 'pages/'.$value.'.php';
          die();
        }
      }

      //establish secure connection to the server
      public static function hm()
      {
        return $this->establishConnection();
      }

      //logout handler
      public function logout()
      {
        //destroy
        unset($_SESSION['admin']);
        session_destroy();
      }

      //delete
      public function delete($data)
      {
        global $hm , $callBack ;
        $callBack['res'] = 0 ;
        $id  = $data['id'];
        $table  = 'ws_'.$data['tb'];
        $query = $hm->query("DELETE FROM `$table` WHERE `id` = $id ");
        if ($query) {
          $callBack['res'] = 1 ;
        }else {
          $callBack['res'] = 0 ;
        }
        return $callBack;
      }

      //next id
      public function nextId($tb)
      {
        global $hm ;
        $menu = $hm->query("SELECT id FROM `$tb`");
        return $menu->rowCount() + 1 ;
      }
    }

 ?>
