<?php
  /**
   * session manger
   * @author : wibgates kenneth , joel.s
   * @copyright : 2018 ws partners
   * @license : MIT
   * @github : git:wibgates/ws_cms
   */
    class session extends users
    {

      function __construct()
      {
        global $ws ;
        if (isset($_SESSION['admin']) && !empty($_SESSION['admin'])) {
            return $this->location('home','inc');
        }else {
          if (!$this->get('admin')) {
            return $this->location('register','inc');
          } else {
            return $this->location('login','inc');
          }
        }
      }
    }


 ?>
