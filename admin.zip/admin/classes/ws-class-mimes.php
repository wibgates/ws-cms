<?php
  /**
   * mime handler
   * @author : wibgates kenneth , joel.s
   * @copyright : 2018 ws partners
   * @license : MIT
   * @github : git:wibgates/ws_cms
   */
   class mimes extends main
   {
     public static function mime($type)
     {
        $mimes = array(
        'text' =>'text/plain' ,
        'html' =>'text/html' ,
        'jpeg' =>'image/jpeg' ,
        'png' =>'image/png' ,
        'mpeg' =>'audio/mpeg' ,
        'ogg' =>'audio/ogg' ,
        'audio' =>'audio' ,
        'mp4' =>'video/mp4' ,
        'app' =>'application' ,
        'json' =>'application/json' ,
        'jscript' =>'application/javascript' ,
        'esm' =>'application/ecmascript' ,
        'stream' =>'application/octet-stream' );
        echo  header("Content-Type:".$mimes[$type]) ;
     }
   }

 ?>
