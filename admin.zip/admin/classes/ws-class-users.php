<?php
    /**
     * users class handler
     * @author : wibgates kenneth , joel.s
     * @copyright : 2018 ws partners
     * @license : MIT
     * @github : git:wibgates/ws_cms
     */

    class users extends main
    {

      public static function aouth($username,$pass=null)
      {
        global $hm , $callBack;
        $pass = md5($pass);
        $query = $hm->query("SELECT id FROM `ws_users` WHERE `username`='$username'  AND `password`='$pass'");
        if ($query->rowCount() == 1 ) {
          return $query->fetch()['id'];
        }else{
          return false;
        }
      }

      public static function signup($data)
      {
        global $hm , $callBack;
        $users = new users ;
        $pass = md5($data['password']);
        $username = $data['username'] ;
        $role = 'admin' ;
        if (!$users->get('admin')) {
          $query = $hm->query("INSERT INTO `ws_users`(`id`, `username`, `password`,`role`)
          VALUES(NULL,'".$username."','".$pass."','".$role."')");
          if ($query) {
            return true;
          }else{
            return false;
          }
        }else {
          return false;
        }
      }

      public static function signin($data)
      {
        global $hm , $callBack;
        $users = new users ;
        $pass = md5($data['password']);
        $username = $data['username'] ;
        $query = $hm->query("SELECT * FROM `ws_users` WHERE `username`='".$username."' AND `password`='".$pass."' LIMIT 1");
        if ($query->rowCount() === 1 ) {
          return $query->fetch();
        }else {
          return false;
        }
      }


      public static function get($username)
      {
        global $hm , $callBack;
        $query = $hm->query("SELECT * FROM `ws_users` WHERE `username`='".$username."'");
        if ($query->rowCount() >= 1 ) {
          $callBack['result'] = $query->fetch();
          $callBack['status'] = 1 ;
        }
        return $callBack;
      }
    }


 ?>
