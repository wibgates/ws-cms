<?php
   /**
    * boot ajax calls
    * this file handles api requests from http interfaces
    * requests are handled singly
    * for multiple requests, interfaces are split and handled in bits
    * @author : wibgates kenneth , joel.s
    * @copyright : 2018 ws partners
    * @license : MIT
    * @github : git:wibgates/ws_cms
    */

    //__initialise session
    include_once '../inc/ws-session.inc';
    //call connection
    include_once '../classes/ws-class-connector.php';
    /**
     * __autoload classes from library
     */
    spl_autoload_register(function ($class_name) { include '../classes/ws-class-'. $class_name . '.php'; });

    /**
     * request new http interfaces
     * caputer all http interfaces
     */
     mimes::mime('html');
     $logout = new main ;
     $logout->logout();
     $logout->location('../../');
 ?>
