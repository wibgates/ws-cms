<?php
    //initialise session
    include_once 'inc/ws-session.inc';
    //auto load ws classes
    spl_autoload_register(function ($class_name) { include 'classes/ws-class-'. $class_name . '.php'; });
    //call all contants
    include_once 'inc/ws-constants.inc';
    //caputer all http interfaces
    new httpInt() ;
    //initialise new session for new user
    new session() ;
 ?>
