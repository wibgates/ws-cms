<div class="container-fluid">
  <div class="row">
      <div class="col-sm-12">
          <div class="page-title-box">
              <h4 class="page-title">Home Page</h4>
          </div>
      </div>
  </div>
  <div class="row">
    <div class="col-md-3">
      <div class="card m-b-30">
          <div class="card-header">
              <h4 class="card-title font-20 mt-0">Components</h4>
          </div>
          <div class="card-body">
            <div class="card">
               <div class="card-header" role="tab" id="headingOne">
                   <h5 class="mb-0 mt-0 font-16">
                       <a data-toggle="collapse" onclick="ws.pg.load('hc_wrap','components-carousel');" href="#Carousel" aria-expanded="true" aria-controls="" class="text-dark">
                          <i class="ti-angle-right"></i> Carousel
                       </a>
                   </h5>
               </div><br>
               <div class="card-header" role="tab" id="headingOne">
                   <h5 class="mb-0 mt-0 font-16">
                       <a data-toggle="collapse" onclick="ws.pg.load('hc_wrap','components-post')" href="#Post" aria-expanded="true" aria-controls="" class="text-dark">
                          <i class="ti-angle-right"></i> Posts
                       </a>
                   </h5>
               </div>
           </div>
          </div>
      </div>
    </div>
    <div class="col-md-9">
      <div class="card m-b-30" id="hc_wrap">

      </div>
    </div>
  </div>
</div>
