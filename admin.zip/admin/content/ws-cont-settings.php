<div class="container-fluid">
  <div class="row">
      <div class="col-sm-12">
          <div class="page-title-box">
              <h4 class="page-title">General Settings</h4>
          </div>
      </div>
  </div>
  <div class="row">
    <div class="col-md-3">
      <div class="card m-b-30">
          <div class="card-header">
              <h4 class="card-title font-20 mt-0">General options</h4>
          </div>
          <div class="card-body">
            <div class="card">
               <div class="card-header" role="tab" id="headingOne">
                   <h5 class="mb-0 mt-0 font-16">
                       <a data-toggle="collapse" onclick="ws.pg.load('s_wrap','settings-logo');" href="#logo" aria-expanded="true" aria-controls="" class="text-dark">
                          <i class="ti-angle-right"></i> Site Logo
                       </a>
                   </h5>
               </div><br>
               <div class="card-header" role="tab" id="headingOne">
                   <h5 class="mb-0 mt-0 font-16">
                       <a data-toggle="collapse" onclick="ws.pg.load('s_wrap','settings-address')" href="#logo" aria-expanded="true" aria-controls="" class="text-dark">
                          <i class="ti-angle-right"></i> Contact & Address
                       </a>
                   </h5>
               </div><br>
               <div class="card-header" role="tab" id="headingOne">
                   <h5 class="mb-0 mt-0 font-16">
                       <a data-toggle="collapse" onclick="ws.pg.load('s_wrap','settings-category')" href="#logo" aria-expanded="true" aria-controls="" class="text-dark">
                          <i class="ti-angle-right"></i> Categories
                       </a>
                   </h5>
               </div>
           </div>
          </div>
      </div>
    </div>
    <div class="col-md-9">
      <div class="card m-b-30" id="s_wrap">
          <div class="card-body">
          <div class="row">
            <div class="col-md-6 col-lg-6 col-xl-3">
                <div class="card m-b-30">
                    <img class="card-img-top img-fluid" id="site_logo" src="#" alt="semu logop">
                    <div class="card-body">
                        <p class="card-text">Site Logo</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-9">
                <div class="card m-b-30 card-body">
                    <h4 class="card-title font-20 mt-0">Contact and Address</h4>
                    <div class="card m-b-30 card-body">
                        <h4 class="card-title font-20 mt-0">Email</h4>
                        <p class="card-text">
                          <span id="st_email"><small>loading..</small> </span>
                        </p>
                    </div>
                    <div class="card m-b-30 card-body">
                        <h4 class="card-title font-20 mt-0">Telephony</h4>
                        <p class="card-text">
                          <span id="st_tel"><small>loading..</small> </span>
                        </p>
                    </div>
                    <div class="card m-b-30 card-body">
                        <h4 class="card-title font-20 mt-0">P.O BOX</h4>
                        <p class="card-text">
                          <span id="st_box"><small>loading..</small> </span>
                        </p>
                    </div>
                    <div class="card m-b-30 card-body">
                        <h4 class="card-title font-20 mt-0">ADDRESS</h4>
                        <p class="card-text">
                          <span id="st_add"><small>loading..</small> </span>
                        </p>
                    </div>
                </div>
            </div>
          </div>
          </div>
      </div>
    </div>
  </div>
</div>
