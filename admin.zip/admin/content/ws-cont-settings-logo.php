<div class="card-header">
    <h4 class="card-title font-20 mt-0">Site Logo </h4>
</div>
<div class="card-body">
    <div class="row">
      <div class="col-md-6 col-lg-6 col-xl-3">
          <div class="card m-b-30">
              <img class="card-img-top img-fluid" id="site_logo" src="#" alt="semu logop">
              <div class="card-body">
                  <p class="card-text">Site Logo</p>
              </div>
          </div>
          <button type="button" data-toggle="modal" data-target="#chg_site_logo" class="btn btn-outline-dark  btn-sm waves-effect waves-light"  name="button">Change</button>
          <div class="modal fade" id="chg_site_logo" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title" id="">Upload Site Logo</h4>
                </div>
                <form method="post" enctype="multipart/form-data" class="form-control">
                  <div class="modal-body">
                    <div class="form-group">
                      <label for="">Upload</label>
                      <input type="hidden" name="yname" value="logo">
                      <input type="file" name="xname" class="form-control">
                      <input type="hidden" name="req" value="upload">
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancle</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
      </div>
    </div>
</div>
