"use-strict"
//data buket handler
ws.bucket = new Object();

//menu bucket
ws.bucket.menu = new Object();

ws.bucket.menu.dump = () => {
    ws.params.mdump = {
      req:'fetch_menu',
      limit1:0,
      limit2:25,
      order:'ASC'
    }
    var bucket = $("#mn_bucket") ;
    bucket.empty();
    $.getJSON(ws.path('api',null), ws.params.mdump, function(json, textStatus) {
        if (json.res == 1 ) {
           //literate thru object
           $.each(json.data, function( key, val ) {
             var id = val.id ;
             var name = val.name ;
             var links = val.links ;
             var pos = val.pos ;

             bucket.append(`<tr id="d_${id}">
               <td class="text-center" id="n_${id}">${name}</td>
               <td class="text-center"><span class="btn btn-outline-info btn-sm waves-effect waves-light">View</span></td>
               <td class="text-center text-primary font-weight-bold" id="ps_${id}">${pos}</td>
               <td class="text-center">
                 <button class="btn btn-info btn-sm" data-toggle="modal" data-target="#e_${id}">
                   <i class="ti-pencil"></i>
                 </button>
                 <div class="modal fade" id="e_${id}" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true">
                   <div class="modal-dialog">
                     <div class="modal-content modal-md">
                       <div class="modal-header">
                         <h4 class="modal-title" id="">Edit: ${name}</h4>
                       </div>
                       <div class="modal-body">
                       <span id="msg_${id}">&nbsp;</span>
                       <div class="form-group">
                         <label for="">Name</label>
                         <input type="text" class="form-control" id="mn_name_${id}" value="${name}" placeholder=""><br>
                         <label for="">Position</label>
                         <input type="number" class="form-control" id="mn_pos_${id}" value="${pos}" placeholder=""><br>
                         <div class="form-group" id="mn_links_bd">
                         <label for="">Drop links</label>
                         <input type="text" class="form-control" id="mn_links_${id}" value="${links}" placeholder="link1,link2,link3,...">
                       </div>
                       </div>
                       <div class="modal-footer">
                         <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                         <button type="button" onclick="ws.pg.menu.update(${id})" class="btn btn-primary btn-sm">Save</button>
                       </div>
                     </div>
                   </div>
                 </div>
               </td>
               <td class="text-center">
                 <button onclick="ws.delete(${id},'app_menu','d_${id}')" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#">
                   <i class="ti-trash"></i>
                 </button>
               </td></tr>`);
          });
        }
    });
}
ws.bucket.menu.dump();

//fetch address
ws.comp.stad.get = () => {
  ws.params.add = {
    req:'fetch_add'
  }
   $.getJSON(ws.path('api',null), ws.params.add, function(json, textStatus) {
       /*optional stuff to do after success */
      $("#st_email").empty();
       $.each(json.email , function(k, v) {
          $("#st_email").append(
            `<p><i class="ti-arrow-right"></i>. <b>${v}</b></p>`
          );
       });

       $("#st_tel").empty();
        $.each(json.tel , function(k, v) {
           $("#st_tel").append(
             `<p><i class="ti-arrow-right"></i>. <b>${v}</b></p>`
           );
        });

        $("#st_box").empty();
        $("#st_box").html(`<p><i class="ti-arrow-right"></i>. <b>${json.box}</b></p>`);

        $("#st_add").empty();
        $("#st_add").html(`<p><i class="ti-arrow-right"></i>. <b>${json.add}</b></p>`);
   });
}

setInterval(function () {
   ws.comp.stad.get();
}, 3000);
