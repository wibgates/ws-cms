<div class="container-fluid">
  <div class="row">
      <div class="col-sm-12">
          <div class="page-title-box">
              <h4 class="page-title">Menu Settings</h4>
          </div>
      </div>
  </div>
  <div class="row">
    <div class="col-md-3">
      <div class="card m-b-30">
          <div class="card-header">
              <h4 class="card-title font-20 mt-0">Create New Menu</h4>
          </div>
          <div class="card-body">
              <span id="mn_msg">&nbsp;</span>
              <div class="form-group">
                <label for="">Name</label>
                <input type="text" class="form-control" id="mn_name" placeholder=""><br>
                <label for=""> <i class="ti-link"></i> Custom Link <small>(optional)</small> </label>
                <input type="text" class="form-control" id="mn_clink" placeholder=""><br>
                <label for=""> <i class="ti-angle-double-down"></i> Has Dropdown </label>
                <select class=" form-control c-select" id="mn_has" onchange="ws.pg.menu.hasList()">
                  <option value="0" selected>No</option>
                  <option value="1">Yes</option>
                </select>
              </div>
              <div class="form-group" id="mn_list_bd">
                <label for="">Drop List</label>
                <input type="text" class="form-control" id="mn_list" placeholder="link1,link2,link3,...">
              </div>
          </div>
          <div class="car-footer">
            <button type="button" id="mn_save" onclick="ws.pg.menu.create()" class="btn btn-primary btn-lg btn-block">Save</button>
          </div>
      </div>
    </div>
    <div class="col-md-9">
      <div class="card m-b-30">
          <div class="card-header">
              <h4 class="card-title font-20 mt-0">Menu Structure <button type="button" class="btn btn-outline-dark  btn-sm waves-effect waves-light" onclick="ws.bucket.menu.dump()" name="button">Show Menu</button></h4>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered table-stripped">
                <thead class="text-center text-uppercase bg-red">
                  <th class="font-weight-bold">Menu Name</th>
                  <th class="font-weight-bold">Nodes</th>
                  <th class="font-weight-bold">Position</th>
                  <th class="font-weight-bold">Edit</th>
                  <th class="font-weight-bold">Delete</th>
                </thead>
                <tbody id="mn_bucket">
                  &nbsp;
                </tbody>
              </table>
            </div>
          </div>
      </div>
    </div>
  </div>
</div>
