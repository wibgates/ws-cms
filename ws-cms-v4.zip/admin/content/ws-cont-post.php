<div class="card-header">
    <div class="row">
      <div class="col-md-4">
        <h4 class="card-title font-20 mt-0"> <span id="hp_sort_cat_t"></span> Post Viewer</h4>
      </div>
      <div class="col-md-2">
        <button type="button" data-toggle="modal" data-target="#create_post" class="btn btn-outline-dark  btn-sm waves-effect waves-light"  name="button"><i class="ti-plus"></i> New Post</button>
      </div>
      <div class="col-md-2">
        <div class="btn-group m-b-10">
            <button type="button" onclick="ws.posts.cat.drop()" class="btn btn-sm btn-outline-dark dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="ti-search"></i> Sort Posts</button>
            <div class="dropdown-menu" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 36px, 0px); top: 0px; left: 0px; will-change: transform;">
                <span id="hp_sort_categories_drop"><a class="dropdown-item" href="#">loading..</a></span>
            </div>
        </div>
      </div>
    </div>
</div>
<div class="card-body">
    <div class="row" id="hp_posts">
      <div class="alert alert-primary" role="alert">
         <strong>Please : </strong> click on <a href="#" onclick="ws.posts.fetch('Blog')">blogs</a> or <a href="#" onclick="ws.posts.fetch('News')">news</a> posts
     </div>
    </div>
    <div class="modal fade" id="i_m_cap" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Edit Caption</h4>
          </div>
          <div class="modal-body">
            <span id="i_m_cap_msg">&nbsp;</span>
            <span class="label label-default font-weight-bold">Tile</span>
            <input type="text" class="form-control" autofocus id="i_m_cap_t" name="" value=""><br>
            <span class="label label-default font-weight-bold">Discription <i><small>(500 words)</small></i> </span>
            <textarea name="name" class="form-control" rows="8" cols="30" id="i_m_cap_b"></textarea>
            <input type="hidden" id="i_m_cap_n" name="name" value="">
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="button" onclick="ws.comp.savecap()" class="btn btn-primary">Save</button>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-6 col-lg-6 col-xl-3">
          <div class="modal fade" id="create_post" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true">
            <div class="modal-dialog modal-lg">
              <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title" id="">create new post</h4>
                </div>
                <form method="post" enctype="multipart/form-data" class="form-control">
                  <div class="modal-body">
                    <div class="form-group">
                      <span class="label label-default font-weight-bold">Post Title</span>
                      <input type="text" class="form-control" name="title" onclick="ws.posts.cat.drop()" required value="">
                    <span class="label label-default font-weight-bold">Post Content <i><small>(2500 words)</small></i> </span>
                    <textarea name="content" class="form-control" required rows="8" cols="30" placeholder="write something here...."></textarea>
                      <label for="">Featured Image</label>
                      <input type="hidden" name="yname" value="post_<?php echo rand(1111,9999); ?>">
                      <input type="file" name="xname" class="form-control">
                      <input type="hidden" name="req" value="create_post"><br>
                      <div class="row"><br>
                        <div class="col-md-6">
                          <span class="label label-default font-weight-bold">Tag</span>
                          <input type="text" name="tags" class="form-control" value=""><br>
                        </div>
                        <div class="col-md-6">
                          <span class="label label-default font-weight-bold">Post Category</span>
                          <select class="form-control" id="hp_categories_drop" name="category">
                            <option value="">loading...</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Discard</button>
                    <button type="submit" class="btn btn-primary">Save Post</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
      </div>
    </div>
</div>
