<div class="card-header">
    <div class="row">
      <div class="col-md-4">
        <h4 class="card-title font-20 mt-0"> <span id="hp_sort_cat_t"></span> Post Featured Image</h4>
      </div>
      <div class="col-md-2">
        <button type="button" data-toggle="modal" data-target="#create_fimage" class="btn btn-outline-dark  btn-sm waves-effect waves-light"  name="button"><i class="ti-plus"></i> Set New</button>
      </div>
      <div class="col-md-2">

      </div>
    </div>
</div>
<div class="card-body">
    <div class="row">
      <div class="table-responsive">
        <table class="table table-bordered table-stripped">
          <thead class="text-center text-uppercase bg-red">
            <th class="font-weight-bold">Post Id</th>
            <th class="font-weight-bold">View</th>
            <th class="font-weight-bold">Delete</th>
          </thead>
          <tbody id="hp_posts_fimg">
            <tr>
              <td colspan="3">
                <div class="alert alert-info" role="alert">
                  <strong>Please hold on!</strong> loading featured images...
                </div>
              </td>
            </tr>
          </tbody>
          <div class="modal fade" id="fimage" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true">
            <div class="modal-dialog modal-md">
              <div class="modal-content">
                <div class="modal-body">
                  <img src="" id="fimage_v" alt="" class="img-rounded img-fluid center-block">
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
              </div>
            </div>
          </div>
        </table>
      </div>
    </div>
    <div class="row">
      <div class="col-md-6 col-lg-6 col-xl-3">
          <div class="modal fade" id="create_fimage" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true">
            <div class="modal-dialog modal-lg">
              <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title" id="">Post featured image</h4>
                </div>
                <form enctype="multipart/form-data" method="post" autocomplete="off">
                  <div class="modal-body">
                      <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 form-control-label">Choose Image</label>
                        <div class="col-sm-10">
                          <input name="xname" type="file" onchange="ws.posts.cat.drop()" class="form-control" id="" placeholder="featured image">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 form-control-label">Post/Page</label>
                        <div class="col-sm-10">
                          <select class="form-control" id="hp_categories_drop" name="category">
                            <option value="">Please first select image...</option>
                          </select>
                        </div>
                      </div>
                      <input type="hidden" name="req" value="create_post_fimage"><br>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Discard</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                  </div>
               </form>
              </div>
            </div>
          </div>
      </div>
    </div>
</div>
