<div class="card-header">
    <h4 class="card-title font-20 mt-0">Category
        <button type="button" data-toggle="modal" data-target="#create_cat" class="btn btn-outline-dark  btn-sm waves-effect waves-light"  name="button"> <i class="ti-plus"></i> New Category</button> </h4>
</div>
<div class="card-body">
    <div class="row" id="hp_categories">
      <div >
        <div class="alert alert-primary" role="alert">
           <strong>Please wait</strong> <a href="#" class="alert-link">loading categories</a>...
       </div>
      </div>
    </div>
    <div class="modal fade" id="pc_m_cap" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Edit Category</h4>
          </div>
          <div class="modal-body">
            <span id="pc_c_msg">&nbsp;</span>
            <span class="label label-default font-weight-bold">Category Name</span>
            <input type="text" class="form-control" autofocus id="pc_c_n" name="" value=""><br>
            <input type="hidden" id="pc_c_i" name="pc_id" value="">
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="button" onclick="ws.posts.cat.upsave()" class="btn btn-primary">Save</button>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-6 col-lg-6 col-xl-3">
          <div class="modal fade" id="create_cat" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true">
            <div class="modal-dialog modal-sm">
              <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title" id="">Create Category</h4>
                </div>
                <div class="modal-body">
                  <span id="p_c_msg"></span>
                  <div class="form-group">
                    <span class="label label-default font-weight-bold">Category Name</span>
                    <input type="text" class="form-control" id="p_c_name" required value="">
                    <input type="hidden" name="req" value="category">
                  </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Cancle</button>
                  <button type="submit" onclick="ws.posts.cat.create()"  class="btn btn-primary">Save</button>
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
</div>
