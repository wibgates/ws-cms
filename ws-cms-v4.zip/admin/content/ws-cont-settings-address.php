<div class="card-header">
    <h4 class="card-title font-20 mt-0">Address</h4>
</div>
<div class="card-body">
  <div class="card m-b-30 card-body">
      <h4 class="card-title font-20 mt-0">Email</h4>
      <p class="card-text">
        <span id="st_email"><small>loading..</small> </span>
      </p>
  </div>
  <div class="card m-b-30 card-body">
      <h4 class="card-title font-20 mt-0">Telephony</h4>
      <p class="card-text">
        <span id="st_tel"><small>loading..</small> </span>
      </p>
  </div>
  <div class="card m-b-30 card-body">
      <h4 class="card-title font-20 mt-0">P.O BOX</h4>
      <p class="card-text">
        <span id="st_box"><small>loading..</small> </span>
      </p>
  </div>
  <div class="card m-b-30 card-body">
      <h4 class="card-title font-20 mt-0">ADDRESS</h4>
      <p class="card-text">
        <span id="st_add"><small>loading..</small> </span>
      </p>
  </div>
    <div class="row">
      <div class="col-md-6 col-lg-6 col-xl-3">
          <button type="button" data-toggle="modal" data-target="#chg_site_add" class="btn btn-outline-dark  btn-sm waves-effect waves-light"  name="button">Change</button>
          <div class="modal fade" id="chg_site_add" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title" id="">Site Address</h4>
                </div>
                <div class="modal-body">
                  <span id="stad_msg">&nbsp;</span>
                  <div class="form-group">
                    <label for="">Email</label>
                    <input type="email" id="stad_email" class="form-control" value="" placeholder="someone@site.com, info@site.com..."><br>
                    <label for="">Telephony</label>
                    <input type="text" id="stad_tel" class="form-control" value="" placeholder="+256 700 000 000, +256 700 000 000..."><br>
                    <label for="">Box Number</label>
                    <input type="text" id="stad_box" class="form-control" value="" placeholder="P.O BOX 000"><br>
                    <label for="">Address</label>
                    <input type="text" id="stad_add" class="form-control" value="" placeholder="Kampal, London st..."><br>
                  </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Cancle</button>
                  <button type="submit" onclick="ws.comp.stad.add()" class="btn btn-primary">Save</button>
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
</div>
