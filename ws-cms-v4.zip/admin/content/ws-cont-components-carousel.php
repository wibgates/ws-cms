<div class="card-header">
    <h4 class="card-title font-20 mt-0">Home Page Slider
        <button type="button" data-toggle="modal" data-target="#chg_slide_1" class="btn btn-outline-dark  btn-sm waves-effect waves-light"  name="button"> <i class="ti-plus"></i> Upload New Slides</button> </h4>
</div>
<div class="card-body">
    <div class="row" id="hp_slides">
      <div >
        <div class="alert alert-primary" role="alert">
           <strong>Please wait</strong> <a href="#" class="alert-link">loading slides</a>...
       </div>
      </div>
    </div>
    <div class="modal fade" id="i_m_cap" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Edit Caption</h4>
          </div>
          <div class="modal-body">
            <span id="i_m_cap_msg">&nbsp;</span>
            <span class="label label-default font-weight-bold">Tile</span>
            <input type="text" class="form-control" autofocus id="i_m_cap_t" name="" value=""><br>
            <span class="label label-default font-weight-bold">Discription <i><small>(500 words)</small></i> </span>
            <textarea name="name" class="form-control" rows="8" cols="30" id="i_m_cap_b"></textarea>
            <input type="hidden" id="i_m_cap_n" name="name" value="">
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="button" onclick="ws.comp.savecap()" class="btn btn-primary">Save</button>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-6 col-lg-6 col-xl-3">
          <div class="modal fade" id="chg_slide_1" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title" id="">Upload Slides</h4>
                </div>
                <form method="post" enctype="multipart/form-data" class="form-control">
                  <div class="modal-body">
                    <div class="form-group">
                      <span class="label label-default">Slide Title</span>
                      <input type="text" class="form-control" name="zname" required value="">
                    <span class="label label-default">Slide Discription <i><small>(500 words)</small></i> </span>
                    <textarea name="meta" class="form-control" required rows="8" cols="30" placeholder=" some one is doing something good on the internet..."></textarea>
                      <label for="">Slide Image</label>
                      <input type="hidden" name="yname" value="slide_<?php echo rand(1111,9999); ?>">
                      <input type="file" name="xname" class="form-control">
                      <input type="hidden" name="req" value="upload">
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancle</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
      </div>
    </div>
</div>
