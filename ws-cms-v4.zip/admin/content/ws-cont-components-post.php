<div class="card-header">
    <div class="row">
      <div class="col-md-4">
        <h4 class="card-title font-20 mt-0"> <span id="hp_sort_cat_t"></span> Posts</h4>
      </div>
      <div class="col-md-8">
        <button type="button" data-toggle="modal" data-target="#create_post" class="btn btn-outline-dark  btn-sm waves-effect waves-light"  name="button"><i class="ti-plus"></i> New Post</button>
        <button type="button" data-toggle="modal" data-target="#post_view_type" onclick="ws.posts.cat.drop()" class="btn btn-sm btn-outline-dark dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="ti-search"></i> Sort Posts</button>
      </div>
      <div class="col-md-12">
        <div class="btn-group m-b-10">
            <div class="modal fade bs-example-modal-sm show" id="post_view_type" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true">
              <div class="modal-dialog modal-lg">
                <div class="modal-content">
                  <div class="modal-header">
                    <div class="col-sm-12 col-md-6">
                      <h4>Post Category:</h4>
                    </div>
                    <div class="col-sm-12 col-md-6 pull-right">
                      <div id="post_search_filter" class="dataTables_filter">
                       <small>nothing found...</small>
                      </div>
                    </div>
                  </div>
                  <div class="modal-body">
                    <div class="custom-dd dd" id="post_nestable_bucket">
                      <div class="row">
                        <div class="col-md-4 col-sm-2">
                          <span class="label label-default font-weight-bold">Main Pages</span>
                          <ol class="dd-list" id="hp_categories_sort">
                          </ol>
                        </div>
                        <div class="col-md-4 col-sm-2">
                          <span class="label label-default font-weight-bold">Sub Pages</span>
                          <ol class="dd-list" id="hp_categories_sort_links">
                          </ol>
                        </div>
                        <div class="col-md-4 col-sm-2">
                          <span class="label label-default font-weight-bold">Sub Pages</span>
                          <ol class="dd-list" id="hp_categories_sort_links_2">
                          </ol>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                  </div>
                </div>
              </div>
            </div>
        </div>
      </div>
    </div>
</div>
<div class="card-body">
    <div class="row">
      <div class="table-responsive">
        <table class="table table-bordered table-stripped">
          <thead class="text-center text-uppercase bg-red">
            <th class="font-weight-bold">Post Id</th>
            <th class="font-weight-bold">Title</th>
            <th class="font-weight-bold">Edit</th>
            <th class="font-weight-bold">View</th>
            <th class="font-weight-bold">Delete</th>
          </thead>
          <tbody id="hp_posts">
              <tr>
                <td class="text-center px-2" colspan="5"><div class="alert alert-primary" role="alert">
                   <strong>Please : </strong> click on <a href="#" onclick="ws.posts.fetch('Blog','0')">blogs</a> or <a href="#" onclick="ws.posts.fetch('News','0')">news</a> posts
               </div></td>
              </tr>
          </tbody>
        </table>
      </div>
    </div>
    <div class="modal fade" id="post_edit" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Edit : <span id="mp_e_title_h"></span> </h4>
          </div>
          <div class="modal-body">
            <span id="mp_e_msg">&nbsp;</span>
            <span class="label label-default font-weight-bold">Tile</span>
            <input type="text" class="form-control" autofocus id="mp_e_title" onclick="ws.posts.cat.drop()" name="" value=""><br>
            <span class="label label-default font-weight-bold">Discription <i><small>(500 words)</small></i> </span>
            <div class="" id="mp_e_text"></div>
            <input type="hidden" id="mp_e_i" name="name" value="">
            <div class="row">
              <div class="col-md-6">
                <span class="label label-default font-weight-bold">Tag <small>(s)</small> </span>
                <input type="text" id="mp_e_tg" name="tags" placeholder="i.e law,finance" class="form-control" value=""><br>
              </div>
              <input type="hidden" id="mp_e_date" value="<?php echo date('Y-m-d h:i') ; ?>">
              <div class="col-md-6">
                <span class="label label-default font-weight-bold">Post Category</span>
                <select class="form-control" id="mp_e_drop" name="category">
                  <option value="">Please first write a title...</option>
                </select>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Cancle</button>
            <!--button type="button" onclick="ws.posts.update.save()" class="btn btn-outline-info"><a href="#" id="mp_e_href"><i class="ti-pencil"></i> Advanced Edit</a> </button-->
            <button type="button" onclick="ws.posts.update.save()" class="btn btn-primary">Update</button>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-6 col-lg-6 col-xl-3">
          <div class="modal fade" id="create_post" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true">
            <div class="modal-dialog modal-lg">
              <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title" id="">Create new post</h4>
                </div>
                <div class="modal-body">
                  <div class="form-group">
                    <span class="label label-default font-weight-bold">Post Title</span>
                    <input type="text" class="form-control" id="create_post_t" name="title" onclick="ws.posts.cat.drop()" required value="">
                    <span class="label label-default font-weight-bold">Post Content <i><small>(2500 words)</small></i> </span>
                    <div class="" id="create_post_i"></div>
                    <input type="hidden" name="yname" id="create_post_n" value="post_<?php echo rand(1111,9999); ?>">
                    <input type="hidden" name="req" value="create_post"><br>
                    <div class="row">
                      <div class="col-md-6">
                        <span class="label label-default font-weight-bold">Tag <small>(s)</small> </span>
                        <input type="text" id="create_post_tg" name="tags" placeholder="i.e law,finance" class="form-control" value=""><br>
                      </div>
                      <input type="hidden" id="create_post_date" value="<?php echo date('Y-m-d h:i') ; ?>">
                      <div class="col-md-6">
                        <span class="label label-default font-weight-bold">Post Category</span>
                        <select class="form-control" id="hp_categories_drop" name="category">
                          <option value="">Please first write a title...</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Discard</button>
                  <button type="submit" onclick="ws.posts.create()" class="btn btn-primary">Save Post</button>
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
</div>
