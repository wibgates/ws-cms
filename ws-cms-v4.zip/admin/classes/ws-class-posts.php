<?php
/**
 * post manger
 * @author : wibgates kenneth , joel.s
 * @copyright : 2018 ws partners
 * @license : MIT
 * @github : git:wibgates/ws_cms
 */
    class posts extends main
    {

      public static function create($data)
      {
        global $hm , $callBack ;
        $main = new main ;
        $callBack['res'] = 0 ;
        $name = trim($data['yname']);
        $title = trim($data['title']);
        $content = trim($data['content']);
        $category = trim($data['category']);
        $tags = json_encode(explode(',',$data['tags']));
        $queryPost = $hm->query("INSERT INTO `ws_app_posts`(`name`, `title`, `content`, `category`, `tags`) VALUES ('".$name."','".$title."','".$content."','".$category."','".$tags."')");
        if ($queryPost) {
           $callBack['res'] = 1 ;
        }
        return $callBack ;
      }

      //update post
      public static function update($data)
      {
        global $hm , $callBack ;
        $callBack['res'] = 0 ;
        $id = $data['id'];
        $title = trim($data['title']);
        $content = trim($data['content']);
        //$category = trim($data['category']);
        //$tags     = json_encode($data['tags']);
        $queryPost = $hm->query("SELECT `id`FROM `ws_app_posts` WHERE `id`='$id'");
        if ($queryPost->rowCount() == 1 ) {
           $updatePost = $hm->query("UPDATE `ws_app_posts` SET `title`='$title',`content`='$content'  WHERE `id`='$id'");
           if ($updatePost) {
              $callBack['res'] = 1 ;
           }else {
             // code...
             $callBack['res'] = 2 ;
           }
        }else {
          $callBack['res'] = 3 ;
        }
        return $callBack ;
      }

      //fetch data
      public static function fetch($data)
      {
        global $hm , $callBack ;
        $callBack['res'] = 0 ;
        $limit1 = $data['limit1'];
        $limit2 = $data['limit2'];
        $order  = $data['order'];
        $cat    = $data['category'];
        $callBack['posts'] = [] ;
        $posts = $hm->query("SELECT * FROM `ws_app_posts` WHERE `category`='$cat' ORDER BY `date` $order LIMIT $limit2 ");
        $rows = $posts->rowCount() ;
        if ($rows <= 0 ) {
          $callBack['res'] = 0 ;
        } else {
          $obj = [] ;
          while ($dataRows = $posts->fetch()) {
            $name = $dataRows['name'] ;
            $obj = [
              'name'=>$name,
              'id'=>$dataRows['id'],
              'title'=>ucfirst($dataRows['title']),
              'content'=>$dataRows['content'],
              'category'=>$dataRows['category'],
              'tags'=>$dataRows['tags'],
              'date'=>$dataRows['date']
            ] ;
            //post image
            $img = $hm->query("SELECT `link` FROM `ws_app_images` WHERE `name`='$name'  limit 1 ");
            if ($img->rowCount() == 1 ) {
              $obj['img'] = $img->fetch()['link'] ;
            }

            array_push($callBack['posts'] , $obj);
          }
          $callBack['res'] = 1 ;
        }
        return $callBack ;
      }

      //fetch featured image
      public static function fimage($data)
      {
        global $hm , $callBack ;
        $callBack['res'] = 0 ;
        $limit1 = $data['limit1'];
        $limit2 = $data['limit2'];
        $order  = $data['order'];
        $callBack['fimage'] = [] ;

        $img = $hm->query("SELECT `name`,`id`,`link` FROM `ws_app_images` WHERE `name` LIKE '%post_%' ORDER BY '$order' LIMIT $limit1,$limit2 ");
        $rows = $img->rowCount() ;
        if ($rows <= 0 ) {
          $callBack['res'] = 0 ;
        } else {
          $obj = [] ;
          while ($dataRows = $img->fetch()) {
            $obj = [
              'name'=>explode('_',$dataRows['name'])[1],
              'id'=>$dataRows['id'],
              'link'=>ucfirst($dataRows['link'])
            ] ;
            array_push($callBack['fimage'] , $obj);
          }
          $callBack['res'] = 1 ;
        }
        return $callBack ;
      }

      //fetch data
      public static function post_id($id)
      {
        global $hm , $callBack ;
        $callBack['res'] = 0 ;
        $callBack['posts'] = [] ;
        $posts = $hm->query("SELECT * FROM `ws_app_posts` WHERE `id`='$id' LIMIT 1 ");
        $rows = $posts->rowCount() ;
        if ($rows <= 0 ) {
          $callBack['res'] = 0 ;
        } else {
          $obj = [] ;
          while ($dataRows = $posts->fetch()) {
            $name = $dataRows['name'] ;
            $obj = [
              'name'=>$name,
              'id'=>$dataRows['id'],
              'title'=>ucfirst($dataRows['title']),
              'content'=>$dataRows['content'],
              'category'=>$dataRows['category'],
              'tags'=>$dataRows['tags'],
              'date'=>$dataRows['date']
            ] ;
            //post image
            $img = $hm->query("SELECT `link` FROM `ws_app_images` WHERE `name`='$name'  limit 1 ");
            if ($img->rowCount() == 1 ) {
              $obj['img'] = $img->fetch()['link'] ;
            }

            array_push($callBack['posts'] , $obj);
          }
          $callBack['res'] = 1 ;
        }
        return $callBack ;
      }
    }

 ?>
