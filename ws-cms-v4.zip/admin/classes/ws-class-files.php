<?php
/**
 * ws file manager
 * @author : wibgates kenneth , joel.s
 * @copyright : 2018 ws partners
 * @license : MIT
 * @github : git:wibgates/ws_cms
 * dalu - naira ali ft da agent
 */
    class files extends posts
    {
      //create dir
      public static function dir($file)
      {
        global $callBack ;
        $callBack['res'] = 1 ;
        if (!file_exists($file)) {
          //create multiple dir or just one
          $dirs = explode('/',$file);
          if (is_array($dirs)) {
            //register main directory max 5 directories
            $main = $dirs[0] ;
            @mkdir($main,0777);
            $child = isset($dirs[1]) ? $dirs[1] : null;
            @mkdir($main.'/'.$child,0777);
            $child2 = isset($dirs[2]) ? $dirs[2] : null;
            @mkdir($main.'/'.$child.'/'.$child2,0777);
            $child3 = isset($dirs[3]) ? $dirs[3] : null;
            @mkdir($main.'/'.$child.'/'.$child2.'/'.$child3,0777);
            $child4 = isset($dirs[4]) ? $dirs[4] : null;
            @mkdir($main.'/'.$child.'/'.$child2.'/'.$child3.'/'.$child4,0777);
            return $callBack;
          }else {
            mkdir($next,0777);
          }
          $callBack['res'] = 1 ;
        }
        return $callBack;
      }

      //write json
      public static function writeJson($data)
      {
        global $callBack ;
        $callBack['res'] = 1 ;
        $path = 'data/'.$data['category'].'/' ;
        files::dir($path);
        unset($data['req']);
        unset($data['tags']['null']);
        $fp = fopen($path.$data['id'].'_'.date('Y').'.json', 'w+');
        fwrite($fp, json_encode($data, JSON_PRETTY_PRINT));   //here it will print the array pretty
        fclose($fp);
        $post_id = explode('_',$data['id'])[1];
        files::pageUrl(strtolower($data['category'].'/') , strtolower($data['title']));
        return $callBack ;
      }

      //read json
      public static function readJson($data)
      {
        global $callBack ;
        $category = $data['category'];
        $limit = $data['limit2'];
        $content = $data['disp'];
        $category = '../api/data/'.$category ;
        if (!file_exists($category)) {
          $callBack['res'] = 0 ;
          return $callBack;
        }
        $files = scandir($category,1) ;
        $count = 0 ;
        foreach ($files as $key => $file) {
           $count++ ;
           if ($count == $limit ) {
           }else {
             if ($file == '..' || $file == '.') {
               //remove un neccessary stings
               unset($file);
             }else {
               $callBack[$key] = json_decode(file_get_contents($category.'/'.$file),TRUE);
               //don't display content from json data of file
               if ($content == 0) {
                 unset($callBack[$key]['content']);
               }else {
                 // code...
                 $callBack[$key]['content'] = stripslashes($callBack[$key]['content']);
               }
             }
           }
        }
        return $callBack ;
      }

      //read one post
      public static function readContent($data)
      {
        global $callBack ;
        $category = $data['category'];
        $id = $data['id'];
        $date = $data['date'];
        $category = '../api/data/'.$category.'/'.$id.'_'.$date.'.json' ;
        if (!file_exists($category)) {
          $callBack['data'] = [];
          return $callBack ;
        }
        $data = json_decode(file_get_contents($category),TRUE);
        //don't display content from json data of file
        $callBack['data'] = $data['content'];
        return $callBack ;
      }

      public static function unlink($data)
      {
        global $callBack;
        $callBack['res'] = 0 ;
        $file = $data['file'].'_'.$data['year'] ;
        $cat = $data['cat'] ;
        $file = '../api/data/'.$cat.'/'.$file.'.json' ;
        if (unlink($file)) {
          $callBack['res'] = 1 ;
        }
        return $callBack;
      }

      //create page url
      public static function pageUrl($page,$title)
      {
        // code...
        $page = str_ireplace(' ','-',$page);
        $title = str_ireplace(' ','-',$title);
        $checkSub = explode('/',$page);
        if (empty($checkSub[1])) {
          //creating sub pages/posts
          //$data = "RewriteRule ^".$page."?$ pages/semu-posts.php\n";
        }else {
          //creating main pages/posts
          //$data = "RewriteRule ^".$page."/?$ pages/semu-posts.php\n";
        }
        $data = "RewriteRule ^".$page."?$ pages/semu-posts.php\n";
        $fp = fopen('../../.htaccess', 'a+');
        fwrite($fp, $data);
        fclose($fp);
      }

      public static function scan($data)
      {
        global $callBack;
        $callBack['res'] = [];
        $dir = 'data/'.$data['dir'];
        $dir = str_ireplace('-',' ',$dir);
        if (!file_exists($dir)) {
          return $callBack;
        }
        $files = scandir($dir,1) ;
        foreach ($files as $key => $file) {
          if ($file == '..' || $file == '.') {
            //remove un neccessary stings
            unset($file);
          }else {
            array_push($callBack['res'],$file);
          }
        }
        return $callBack;
      }
    }
 ?>
