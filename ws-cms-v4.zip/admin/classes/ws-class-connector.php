<?php
    /**
     * mysql pdo connector
     * @author : wibgates kenneth , joel.s
     * @copyright : 2018 ws partners
     * @license : MIT
     * @github : git:wibgates/ws_cms
     */
     //creating a db connector
     $user = 'root' ;
     $pass = null ;
     try {
       $hm = new PDO('mysql:host=localhost;dbname=ws_semu', $user, $pass);
     } catch (\Exception $e) {
        die('Servers failed to connect...');
     }

 ?>
