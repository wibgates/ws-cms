<?php
    /**
     * image manager
     * @author : wibgates kenneth , joel.s
     * @copyright : 2018 ws partners
     * @license : MIT
     * @github : git:wibgates/ws_cms
     */
    class images extends httpInt
    {

      public static function stream($data)
      {
        global $hm , $callBack ;
        $callBack['res'] = 0 ;
        $callBack['path'] = 'uploads/' ;
        $name = $data['name'];
        if ($name == 'slides') {
          $callBack['img'] = [] ;
          $img = $hm->query("SELECT `id` , `link` , `name` FROM `ws_app_images` WHERE `name` LIKE '%slide_%' ");
          if ($img->rowCount() >= 1 ) {
            $callBack['res'] = 1 ;
            $obj = [] ;
            while ($dataRows = $img->fetch()) {
              $obj = [
                'name'=>$dataRows['link'],
                'id'=>$dataRows['id'],
                'lname'=>$dataRows['name']
              ];
              $dataName = $dataRows['name'] ;
              $imgCap = $hm->query("SELECT `cap` , `title` FROM `ws_app_images_caption` WHERE `name`='$dataName'  limit 1 ");
              while ($imgCapRow =  $imgCap->fetch()) {
                $obj['cap'] = $imgCapRow['cap'] ;
                $obj['title'] = $imgCapRow['title'] ;
              }

              array_push($callBack['img'] , $obj );
            }
          }
        }else {
          $img = $hm->query("SELECT * FROM `ws_app_images` WHERE `name`='$name'  limit 1 ");
          if ($img->rowCount() == 1 ) {
            $callBack['res'] = 1 ;
            $callBack['img'] = $callBack['path'].$img->fetch()['link'] ;
            $callBack['target'] = $img->fetch()['target'] ;
            $callBack['name'] = $img->fetch()['name'] ;
          }
        }

        return $callBack;
      }

      public static function edit($data)
      {
        global $hm , $callBack ;
        $callBack['res'] = 0 ;
        $title = $data['title'];
        $cap = $data['cap'];
        $name = $data['name'];
        $imgCap = $hm->query("UPDATE `ws_app_images_caption` SET `title`='$title' ,`cap`='$cap' WHERE `name`='$name'");
        if ($imgCap) {
          $callBack['res'] = 1 ;
        }
        return $callBack;
      }

      public function upload($img,$data)
      {
        global $hm , $callBack ;
        $callBack['res'] = 1 ;
        $name  = $data['yname'];
        $img1 = $hm->query("SELECT `id` FROM `ws_app_images` WHERE `name`='$name'");
        if ($img1->rowCount() <= 0 ) {
          $img = $hm->query("INSERT INTO `ws_app_images`(`name`, `link`, `target`) VALUES ('".$name."','".$img."','black')");
        }else {
          $img = $hm->query("UPDATE `ws_app_images` SET `link`='$img' WHERE `name`='$name'");
        }

        if (!empty($data['zname'])) {
          $title = $data['zname'];
          $cap   = base64_encode($data['meta']);
          $hm->query("INSERT INTO `ws_app_images_caption` (`id`, `name`, `title`, `cap`)
           VALUES (NULL, '".$name."', '".$title."', '".$cap."')");
        }

        return $callBack;
      }

      //remove images from dirs
      public static function remove($img)
      {
        // code...
        global $callBack ;
        $callBack['res'] = 0 ;
        $path = "uploads/".$img ;
        if (file_exists($path)) {
          unlink($path);
          $callBack['res'] = 1 ;
        }
        return $callBack;
      }
    }

 ?>
