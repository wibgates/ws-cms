<?php
    /**
     * address handler
     * @author : wibgates kenneth , joel.s
     * @copyright : 2018 ws partners
     * @license : MIT
     * @github : git:wibgates/ws_cms
     */
    class address extends httpInt
    {

      public static function fetch($data)
      {
        global $hm , $callBack ;
        $callBack['res'] = 0 ;
        $img = $hm->query("SELECT * FROM `ws_app_address`  ORDER BY `id` DESC LIMIT 1  ");
        if ($img->rowCount() == 1 ) {
          $callBack['res'] = 1 ;
          while ($datarows = $img->fetch()) {
            // code...
            $callBack['email'] = json_decode($datarows['email']);
            $callBack['tel'] = json_decode($datarows['tel']);
            $callBack['box'] = $datarows['box'];
            $callBack['add'] = $datarows['address'];
          }
        }
        return $callBack;
      }

      public static function save($data)
      {
        global $hm , $callBack ;
        $callBack['res'] = 0 ;
        $email = json_encode($data['email']);
        $tel = json_encode($data['tel']);
        $box = $data['box'];
        $add = $data['add'];
        $addquery = $hm->query("INSERT INTO `ws_app_address`(`email`, `tel`, `box`, `address`)
         VALUES ('$email','$tel','".$box."','".$add."')");
         if ($addquery) {
           $callBack['res'] = 1 ;
         }

        return $callBack;
      }
    }

 ?>
