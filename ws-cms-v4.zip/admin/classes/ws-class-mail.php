<?php
    /**
     * mail handler
     * @author : wibgates kenneth , joel.s
     * @copyright : 2018 ws partners
     * @license : MIT
     * @github : git:wibgates/ws_cms
     */
    class mail extends main
    {

      public static function send()
      {
        // code...
        //lets do some magic here
      }
    }

 ?>
