<?php
    /**
     * main class:global methods
     * @author : wibgates kenneth , joel.s
     * @copyright : 2018 ws partners
     * @license : MIT
     * @github : git:wibgates/ws-cms
     */
    class main
    {
      /**
       * content manager
       * set mimes based on what page content
       * your are throwing to the browser
       * the default mime is html
       */

      public function location($value='',$mode=null,$mime='html')
      {
        if ($mode == null) {
          mimes::mime($mime);
          return header('location:pages/'.$value);
        } else {
          mimes::mime($mime);
          include 'pages/'.$value.'.php';
          die();
        }
      }

      //establish secure connection to the server
      public static function hm()
      {
        return $this->establishConnection();
      }

      //ws salt
      public function salt($data)
      {
        global $callBack ;
        $val = $data['val'];
        $cmd = $data['cmd'];
        if ($cmd == '641' ) {
          $callBack['res'] = base64_encode($val);
        }elseif ($cmd == '640' ) {
          $callBack['res'] = base64_decode($val);
        }
        return $callBack;
      }

      public function replace($data)
      {
        global $callBack ;
        $val = strtolower($data['val']);
        $p1 = $data['p1'];
        $p2 = $data['p2'];
        $callBack['res'] = str_ireplace($p1,$p2,$val);
        return $callBack;
      }

      //logout handler
      public function logout()
      {
        //destroy
        unset($_SESSION['admin']);
        session_destroy();
      }

      //delete
      public function delete($data)
      {
        global $hm , $callBack ;
        $callBack['res'] = 0 ;
        $id  = $data['id'];
        $table  = 'ws_'.$data['tb'];
        $query = $hm->query("DELETE FROM `$table` WHERE `id` = $id ");
        if ($query) {
          $callBack['res'] = 1 ;
        }else {
          $callBack['res'] = 0 ;
        }
        return $callBack;
      }

      //next id
      public function nextId($tb)
      {
        global $hm ;
        $menu = $hm->query("SELECT id FROM `$tb`");
        return $menu->rowCount() + 1 ;
      }
    }

 ?>
