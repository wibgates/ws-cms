<?php
    /**
     * category manager
     * @author : wibgates kenneth , joel.s
     * @copyright : 2018 ws partners
     * @license : MIT
     * @github : git:wibgates/ws_cms
     */
    class category extends main
    {

      public static function create($data)
      {
        global $hm , $callBack ;
        $main = new main ;
        $callBack['res'] = 0 ;
        $name = ucwords(trim($data['name']));
        $queryCategory = $hm->query("INSERT INTO `ws_app_category`(`name`) VALUES ('".$name."')");
        if ($queryCategory) {
           $callBack['res'] = 1 ;
        }
        return $callBack ;
      }

      //update Category
      public static function update($data)
      {
        global $hm , $callBack ;
        $callBack['res'] = 0 ;
        $name = $data['name'];
        $id   = $data['id'];
        $queryCategory = $hm->query("SELECT `id` FROM `ws_app_category` WHERE `id`='$id' LIMIT 1 ");
        if ($queryCategory->rowCount() == 1 ) {
           $updateCategory = $hm->query("UPDATE `ws_app_category` SET `name`='$name' WHERE `id`='$id' ");
           if ($updateCategory) {
              $callBack['res'] = 1 ;
           }
        }
        return $callBack ;
      }

      //fetch data
      public static function fetch($data)
      {
        global $hm , $callBack ;
        $callBack['res'] = 0 ;
        $limit1 = $data['limit1'];
        $limit2 = $data['limit2'];
        $order  = $data['order'];
        $callBack['cats'] = [] ;
        $Categorys = $hm->query("SELECT * FROM `ws_app_category` ORDER BY `date` $order LIMIT $limit2 ");
        $rows = $Categorys->rowCount() ;
        if ($rows <= 0 ) {
          $callBack['res'] = 0 ;
        } else {
          $obj = [] ;
          while ($dataRows = $Categorys->fetch()) {
            $obj = [
              'name'=>$dataRows['name'],
              'id'=>$dataRows['id'],
              'date'=>$dataRows['date']
            ] ;
            array_push($callBack['cats'] , $obj);
          }
          //add pages
          menu::fetch($data);
          $callBack['res'] = 1 ;
        }
        return $callBack ;
      }
    }

 ?>
